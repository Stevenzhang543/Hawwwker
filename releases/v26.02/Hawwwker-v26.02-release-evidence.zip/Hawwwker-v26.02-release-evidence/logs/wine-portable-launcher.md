# 便携版启动器 Wine 测试（64 位 NSIS 启动器）

环境：Wine 64 位前缀，已写入 WebView2 版本注册表项（HKCU\Software\Microsoft\EdgeUpdate\Clients\{F3017226-…} pv=130.0.2849.80）以通过启动器的运行时检查。

命令：`wine usb\portable.exe --selftest-sites Z:\tmp\winetest\st2.md jd`（HAWWWKER_BROWSER 指向模拟浏览器）

结果：
- 程序文件解压到 %LOCALAPPDATA%\Hawwwker\portable\26.02\：hawwwker.exe、WebView2Loader.dll ✅
- exe 旁边创建 Hawwwker-data\（可写检测通过）✅
- 命令行参数原样传给应用，应用通过管道连上浏览器并写出自检报告 ✅（模拟浏览器不支持建标签页，所以报告里是"无法创建标签页"，这是预期结果）

报告：
```
# Hawwwker 平台自检报告

时间：2026-11-02 01:41:55 +0100  
通过：0 / 1

| 平台 | 结果 | 识别条数 | 含价格 | 用时 | 示例 / 说明 |
|---|---|---:|---:|---:|---|
| 京东 国内版 | ⚠️ 未通过 | 0 | 0 | 0.0s | 无法创建标签页 |
```

说明：Wine 没有 WebView2，界面窗口无法在此环境创建（tao/WebView2 初始化停止），界面需在真实 Windows 上验证。
